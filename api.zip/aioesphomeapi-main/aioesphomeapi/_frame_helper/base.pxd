
import cython

from .._sanitize cimport safe_label_str
from ..connection cimport APIConnection


cdef bint TYPE_CHECKING

cdef int _MAX_NAME_LEN
cdef int _MAX_MAC_LEN
cdef int _MAX_EXPLANATION_LEN

cdef class APIFrameHelper:

    cdef object _loop
    cdef APIConnection _connection
    cdef object _transport
    cdef public object _writelines
    cdef public object ready_future
    cdef bytes _buffer
    cdef unsigned int _buffer_len
    cdef unsigned int _pos
    cdef object _client_info
    cdef str _log_name

    cpdef set_log_name(self, str log_name)

    @cython.final
    @cython.locals(
        original_pos="unsigned int",
        new_pos="unsigned int",
        cstr="const unsigned char *"
    )
    cdef bytes _read(self, int length)

    @cython.final
    @cython.locals(bytes_data=bytes)
    cdef void _add_to_buffer(self, object data) except *

    @cython.final
    @cython.locals(end_of_frame_pos="unsigned int", cstr="const unsigned char *")
    cdef void _remove_from_buffer(self) except *

    cpdef void write_packets(self, list packets, bint debug_enabled) except *

    @cython.final
    cdef void _write_bytes(self, object data, bint debug_enabled) except *

    cdef void _handle_error_and_close(self, Exception exc) except *
